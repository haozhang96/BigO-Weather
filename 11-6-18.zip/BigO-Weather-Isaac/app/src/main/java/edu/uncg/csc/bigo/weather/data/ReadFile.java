package edu.uncg.csc.bigo.weather.data;

/**
 * This class will read the zip code, latitude and longitude from the text file created in
 * CreateFile. It will return this information.
 * @author Harman Bains
 * @updated 10/24/2018
 */

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.InputMismatchException;
import java.util.Scanner;

import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;

public class ReadFile {

    /**
     * This will read the information from the created file and use it to load weather information.
     *  @param _zipcode
     *  @param _context
     *  @return
     *  @throws Exception if the file or directory could not be read from.
     */

    // Returns a LocationCoordinate that can be used.

    public static void readFromFile (Context _context, int _zipcode){
  //      File findFile = new File(_context.getFilesDir(), "LocationFile.txt");

        // Pass in the directory and file name to be read.
        File loadFile = new File(CreateFile.txtDir, "LocationFile.txt");

        try (Scanner scanner = new Scanner(loadFile)) {
            while (scanner.hasNext() ) {
                Log.e("NextInt ", " is: " + scanner.nextInt());
                if( scanner.nextInt() == _zipcode){
                    Log.e("MATCH", " next int matches zipcode " + scanner.nextInt() + " == " + _zipcode);
                }else if(scanner.nextInt() != _zipcode) {
                    Log.e("NO match found", " something in txt file" + scanner.next());

                }
            }
        } catch (FileNotFoundException | InputMismatchException e) {
            e.printStackTrace();
        }

    }
}
