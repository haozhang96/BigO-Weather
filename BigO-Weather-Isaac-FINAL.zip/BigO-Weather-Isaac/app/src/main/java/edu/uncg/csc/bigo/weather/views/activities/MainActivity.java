package edu.uncg.csc.bigo.weather.views.activities;
/**
 *The MainActivity class controls buttons, textboxes, and the general activity of the program. We are
 *using it mainly to set up the UI necessary for testing.
 *
 * updated 10/3/18
 * @authors Hao Zhang, John Wilkinson, Steven Tran, Harman Bains.
 **/
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import edu.uncg.csc.bigo.weather.models.api.LocationAPI;
import edu.uncg.csc.bigo.weather.models.api.WeatherAPI;
import edu.uncg.csc.bigo.weather.models.api.weather.DarkSkyAPI;
import edu.uncg.csc.bigo.weather.models.api.location.GeocodioAPI;
import edu.uncg.csc.bigo.weather.models.metrics.units.TemperatureUnit;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import edu.uncg.csc.bigo.weather.models.weather.WeatherData;
import edu.uncg.csc.bigo.weather.R;


public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private TextView TextViewZipFormat;
    private EditText editTextZip;
    private Button button;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            new Test().execute();
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize the EditText box.
        editTextZip = (EditText) findViewById(R.id.editTextZip);
        //Initialize the button.
        button = (Button) findViewById(R.id.button);
        //Initialize the message TextView box.
        mTextMessage = (TextView) findViewById(R.id.message);
        //Initialize the formatting message TextView box.
        TextViewZipFormat = (TextView) findViewById(R.id.TextViewZipFormat);
        //Set the button to listen for clicks, and do something when it hears one.
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Make sure the user inputs a properly formatted zip.
                if (editTextZip.getText().toString().length()<5 || editTextZip.getText().toString().isEmpty()) {
                    TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                    editTextZip.setText("");
                }
                //If the zip is correctly formatted assign it to zipCode
                else if(editTextZip.getText().toString().length()>=5){
                    int zipCode = Integer.valueOf(editTextZip.getText().toString());
                    TextViewZipFormat.setText("" );

                }
            }
        });

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }


    /**
     * This is where we will test things
     */
    private class Test extends AsyncTask<Void, Void, String> {

        private static final String APIKEY_GEOCODIO = "f0905446086d00db93d937b64d0e999b3b45d5d";
        private static final String APIKEY_DARKSKY = "1fffd54fe65a40d92a13eb5d7e3e1fee";


        protected String doInBackground(Void... nothing) {
            try  {
                // Store a message buffer to append strings to.
                StringBuffer message = new StringBuffer();

                // Initialize the APIs.
                WeatherAPI darkSky = new DarkSkyAPI(Test.APIKEY_DARKSKY);
                LocationAPI geocodio = new GeocodioAPI(Test.APIKEY_GEOCODIO);

                // Get the location of the ZIP code.
                int zipCode = Integer.valueOf(editTextZip.getText().toString());
                LocationCoordinate location = geocodio.zipCodeToCoordinate(zipCode);
                message.append(String.format(
                        "Coordinate of ZIP code %d: %f, %f",
                        zipCode, location.getLatitude(), location.getLongitude()
                ));

                // Get the current weather data for the ZIP code.
                WeatherData testCurrent = darkSky.getCurrentWeather(location);
                message.append("\n\nCurrently:\n" + testCurrent);
                message.append("\nTemperature in C: " + testCurrent.getTemperature().convertTo(TemperatureUnit.CELSIUS));

                // Get the minutely weather data for the ZIP code.
                // This one is very bare minimum.
                //WeatherData testMinutely = darkSky.getMinutelyWeather(location);
                //message.append("\n\nMinutely:\n" + testMinutely);

                // Get the hourly weather data for the ZIP code.
                WeatherData testHourly = darkSky.getHourlyWeather(location);
                message.append("\n\nHourly:\n" + testHourly);

                // Get the daily weather data for the ZIP code.
                WeatherData testDaily = darkSky.getDailyWeather(location);
                message.append("\n\nDaily:\n" + testDaily);

                // Return the built message
                return message.toString();
            } catch (Exception exception) {
                return exception.toString();
            }
        }


        protected void onPostExecute(String result) {
            mTextMessage.setText(result);
        }
    }
}