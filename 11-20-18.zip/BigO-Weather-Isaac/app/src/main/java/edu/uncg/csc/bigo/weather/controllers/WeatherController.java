package edu.uncg.csc.bigo.weather.controllers;
/**
 * This is the placeholder class for the weather controller
 */
public final class WeatherController {

}