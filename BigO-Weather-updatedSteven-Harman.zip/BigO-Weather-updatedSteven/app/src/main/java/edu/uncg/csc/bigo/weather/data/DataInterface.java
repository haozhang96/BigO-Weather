package edu.uncg.csc.bigo.weather.data;

import android.content.Context;

import java.util.ArrayList;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;

/**
 * This interface will describe all the methods which must be implemented for the text file database.
 * @author Harman Bains
 * @updated 10/29/2018
 */

public interface DataInterface {

    public abstract void sortFile();

 //   public abstract LocationCoordinate returnCoordinates (int _zipCode);

    public abstract void insert(int _zipCode, Context _context);

    // Check if the zip code is saved in the text file.
    public abstract boolean checkFile(int _zipCode,Context _context);

    //Currently not in use.
    public abstract void remove(String _zipCode);

}
