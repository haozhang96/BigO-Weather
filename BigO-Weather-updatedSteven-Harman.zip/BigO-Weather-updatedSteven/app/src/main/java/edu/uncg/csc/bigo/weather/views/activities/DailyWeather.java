package edu.uncg.csc.bigo.weather.views.activities;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

import edu.uncg.csc.bigo.weather.R;
import edu.uncg.csc.bigo.weather.controllers.WeatherController;
import edu.uncg.csc.bigo.weather.data.CreateFile;
import edu.uncg.csc.bigo.weather.data.DataInterface;
import edu.uncg.csc.bigo.weather.data.DataStore;
import edu.uncg.csc.bigo.weather.models.util.Globals;
import edu.uncg.csc.bigo.weather.models.weather.Days;
import edu.uncg.csc.bigo.weather.models.weather.Icons;


/**
 * A simple {@link Fragment} subclass.
 */
public class DailyWeather extends Fragment {


    private TextView mTextMessage;
    private TextView TextViewZipFormat;
    private EditText editTextZip;
    private Button button;
    private ImageView monday;
    private ImageView tuesday;
    private ImageView wednesday;
    private ImageView thursday;
    private ImageView friday;
    private ImageView saturday;
    private ImageView sunday;
    private ImageView[] days = {monday, tuesday, wednesday, thursday, friday, saturday, sunday};

    AutoCompleteTextView autoView;

    // Declare the context of the app.
    final Context context = this.getContext();


    public DailyWeather() {
        // Required empty public constructor
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_daily_weather, container, false);

        //Initialize the button
        button = (Button) v.findViewById(R.id.button);

        //Initialize the message TextView box
        mTextMessage = (TextView) v.findViewById(R.id.dailyMessage);

        //Initialize the formatting message TextView box
        TextViewZipFormat = (TextView) v.findViewById(R.id.TextViewZipFormat);

        //Initialize the AutoCompleteTextBox which gets data from the saved text file.
        autoView = (AutoCompleteTextView) v.findViewById(R.id.autoCompleteTextView);

        // This generates the drop down list from the text file for the view.
        try {
            // Pass in the directory and file name to be read.
            File loadFile = new File(CreateFile.sortedFilePath);

            // Create ArrayList and Array that will hold the saved locations.
            ArrayList<String> zipList = new ArrayList<String>();
            String[] zipArray = null;

            try (Scanner scanner = new Scanner(loadFile)) {

                // Clear the arrayList.
                zipList.clear();

                while (scanner.hasNext()) {

                    // Add each location that is saved in the file to the arrayList.
                    zipList.add(scanner.next());
                }

                // Transfer the locations from the ArrayList to an Array so they can be used in the
                // AutoCompleteTextView.
                zipArray = (String[]) zipList.toArray(new String[zipList.size()]);

                // Create an adapter that connects the context, AutoCompleteTextView and the saved locations
                // array together.
                final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),
                        R.layout.support_simple_spinner_dropdown_item, zipArray);

                // Begin displaying the saved locations after the first number has been entered and set
                // the adapter.
                autoView.setThreshold(1);
                autoView.setAdapter(adapter);
            } catch (FileNotFoundException | InputMismatchException e) {
                e.printStackTrace();
            }


            //
            monday = (ImageView) v.findViewById(R.id.monday);

            //
            tuesday = (ImageView) v.findViewById(R.id.tuesday);

            //
            wednesday = (ImageView) v.findViewById(R.id.wednesday);

            //
            thursday = (ImageView) v.findViewById(R.id.thursday);

            //
            friday = (ImageView) v.findViewById(R.id.friday);

            //
            saturday = (ImageView) v.findViewById(R.id.saturday);

            //
            sunday = (ImageView) v.findViewById(R.id.sunday);

            return v;
        } catch (Exception e) {
            Log.e("OnCreateView", " error");
        }

        return v;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        View view = getView();

        if (view != null) {
            view.findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Make sure the user inputs a properly formatted zip.
                    if (autoView.getText().toString().length() < 5 || autoView.getText().toString().isEmpty()) {
                        TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                        mTextMessage.setText(" ");
                        autoView.setText("");
                    } else if (autoView.getText().toString().length() > 5) {
                        TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                        mTextMessage.setText(" ");
                        autoView.setText("");
                    }
                    //If the zip is correctly formatted assign it to zipCode
                    else if (autoView.getText().toString().length() == 5) {
                        int zipCode = Integer.valueOf(autoView.getText().toString());
                        autoView.setText("");
                        new Test(context).execute();
                    }
                }
            });
        }
    }


    /**
     * This is where we will test things
     */
    public class Test extends AsyncTask<Void, Void, String> {

        private final Context context;

        public Test(final Context _context) {
            context = _context;
        }


        protected String doInBackground(Void... nothing) {
            try {
                // Store a message buffer to append strings to.
                StringBuffer message = new StringBuffer();

                //Get the zipcode entered by the user.
                int zipCode = Integer.valueOf(autoView.getText().toString());

                try {
                    // This is used for CRUD operations.
                    DataInterface dataModifier = new DataStore();

                    dataModifier.insert(zipCode, context);

                } catch (Exception e) {
                    e.toString();
                }

                //Testing the WeatherController methods
                message.append("Daily: \n");
                String[][] testDailyWeatherForecastController = WeatherController.getWeatherDailyForecast(zipCode);
                message.append(testDailyWeatherForecastController[0][Globals.CITY_STATE_ZIP] + "\n");
                for (int i = 0; i < 7; i++) {
                    message.append(testDailyWeatherForecastController[i][Globals.TIME] + "\n");
                    message.append(testDailyWeatherForecastController[i][Globals.SUMMARY] + "\n");
                    message.append("High: " + testDailyWeatherForecastController[i][Globals.TEMP_HIGH]);
                    message.append(", Low: " + testDailyWeatherForecastController[i][Globals.TEMP_LOW] + "\n\n");
                    message.append("Icon: " + testDailyWeatherForecastController[i][Globals.ICON] + "\n\n");
                }
                message.append("\n");

                try {
                    switch (testDailyWeatherForecastController[0][Globals.ICON]) {
                        case "clear-day":
                            Icons clear_day = Icons.valueOf("Clear_day".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(clear_day.getIconResId());

                        case "clear-night":
                            Icons clear_night = Icons.valueOf("Clear_night".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(clear_night.getIconResId());


                        case "cloudy":
                            Icons cloudy = Icons.valueOf("Cloudy".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(cloudy.getIconResId());


                        case "fog":
                            Icons fog = Icons.valueOf("Fog".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(fog.getIconResId());


                        case "partly-cloudy-day":
                            Icons partly_cloudy_day = Icons.valueOf("Partly_cloudy_day".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(partly_cloudy_day.getIconResId());

                        case "partly-cloudy-night":
                            Icons partly_cloudy_night = Icons.valueOf("Partly_cloudy_night".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(partly_cloudy_night.getIconResId());

                        case "rain":
                            Icons rain = Icons.valueOf("Rain".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(rain.getIconResId());


                        case "sleet":
                            Icons sleet = Icons.valueOf("Sleet".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(sleet.getIconResId());


                        case "snow":
                            Icons snow = Icons.valueOf("Snow".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(snow.getIconResId());


                        case "wind":
                            Icons wind = Icons.valueOf("Wind".toUpperCase(Locale.ENGLISH));
                            monday.setImageResource(wind.getIconResId());

                    }

                    switch (testDailyWeatherForecastController[1][Globals.ICON]) {
                        case "clear-day":
                            Icons clear_day = Icons.valueOf("Clear_day".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(clear_day.getIconResId());


                        case "clear-night":
                            Icons clear_night = Icons.valueOf("Clear_night".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(clear_night.getIconResId());


                        case "cloudy":
                            Icons cloudy = Icons.valueOf("Cloudy".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(cloudy.getIconResId());


                        case "fog":
                            Icons fog = Icons.valueOf("Fog".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(fog.getIconResId());


                        case "partly-cloudy-day":
                            Icons partly_cloudy_day = Icons.valueOf("Partly_cloudy_day".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(partly_cloudy_day.getIconResId());


                        case "partly-cloudy-night":
                            Icons partly_cloudy_night = Icons.valueOf("Partly_cloudy_night".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(partly_cloudy_night.getIconResId());


                        case "rain":
                            Icons rain = Icons.valueOf("Rain".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(rain.getIconResId());


                        case "sleet":
                            Icons sleet = Icons.valueOf("Sleet".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(sleet.getIconResId());


                        case "snow":
                            Icons snow = Icons.valueOf("Snow".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(snow.getIconResId());


                        case "wind":
                            Icons wind = Icons.valueOf("Wind".toUpperCase(Locale.ENGLISH));
                            tuesday.setImageResource(wind.getIconResId());

                    }

                    switch (testDailyWeatherForecastController[2][Globals.ICON]) {
                        case "clear-day":
                            Icons clear_day = Icons.valueOf("Clear_day".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(clear_day.getIconResId());


                        case "clear-night":
                            Icons clear_night = Icons.valueOf("Clear_night".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(clear_night.getIconResId());


                        case "cloudy":
                            Icons cloudy = Icons.valueOf("Cloudy".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(cloudy.getIconResId());


                        case "fog":
                            Icons fog = Icons.valueOf("Fog".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(fog.getIconResId());


                        case "partly-cloudy-day":
                            Icons partly_cloudy_day = Icons.valueOf("Partly_cloudy_day".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(partly_cloudy_day.getIconResId());


                        case "partly-cloudy-night":
                            Icons partly_cloudy_night = Icons.valueOf("Partly_cloudy_night".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(partly_cloudy_night.getIconResId());


                        case "rain":
                            Icons rain = Icons.valueOf("Rain".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(rain.getIconResId());


                        case "sleet":
                            Icons sleet = Icons.valueOf("Sleet".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(sleet.getIconResId());


                        case "snow":
                            Icons snow = Icons.valueOf("Snow".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(snow.getIconResId());


                        case "wind":
                            Icons wind = Icons.valueOf("Wind".toUpperCase(Locale.ENGLISH));
                            wednesday.setImageResource(wind.getIconResId());

                    }

                    switch (testDailyWeatherForecastController[3][Globals.ICON]) {
                        case "clear-day":
                            Icons clear_day = Icons.valueOf("Clear_day".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(clear_day.getIconResId());


                        case "clear-night":
                            Icons clear_night = Icons.valueOf("Clear_night".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(clear_night.getIconResId());


                        case "cloudy":
                            Icons cloudy = Icons.valueOf("Cloudy".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(cloudy.getIconResId());


                        case "fog":
                            Icons fog = Icons.valueOf("Fog".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(fog.getIconResId());


                        case "partly-cloudy-day":
                            Icons partly_cloudy_day = Icons.valueOf("Partly_cloudy_day".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(partly_cloudy_day.getIconResId());


                        case "partly-cloudy-night":
                            Icons partly_cloudy_night = Icons.valueOf("Partly_cloudy_night".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(partly_cloudy_night.getIconResId());


                        case "rain":
                            Icons rain = Icons.valueOf("Rain".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(rain.getIconResId());


                        case "sleet":
                            Icons sleet = Icons.valueOf("Sleet".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(sleet.getIconResId());


                        case "snow":
                            Icons snow = Icons.valueOf("Snow".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(snow.getIconResId());


                        case "wind":
                            Icons wind = Icons.valueOf("Wind".toUpperCase(Locale.ENGLISH));
                            thursday.setImageResource(wind.getIconResId());

                    }
                } catch (Exception e) {
                    Log.e("SWITCH", "ERROR");
                }

                return message.toString();
            } catch (Exception exception) {
                Log.e("Down low", " error" + exception.toString());

                return exception.toString();
            }

        }

        protected void onPostExecute(String result) {
            mTextMessage.setText(result);
        }
    }
}


