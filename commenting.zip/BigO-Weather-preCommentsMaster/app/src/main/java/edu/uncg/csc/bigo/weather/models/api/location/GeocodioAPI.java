package edu.uncg.csc.bigo.weather.models.api.location;
/**
 * This class defines the Geocodio location API and its methods.
 *
 * @updated 2018/09/27
 * @authors Harman Bains, Hao Zhang
 */

import edu.uncg.csc.bigo.weather.models.api.LocationAPI;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;

public final class GeocodioAPI extends LocationAPI {
    /**
     * Formats the API call string from the parent class.
     *
     * @param _apiKey
     */
    public GeocodioAPI(String _apiKey) {
        super(String.format("https://api.geocod.io/v1.3/geocode?q=%%d&api_key=%s", _apiKey));
    }

    /**
     * Currently unsupported method.
     *
     * @return
     * @throws UnsupportedOperationException
     */
    public LocationCoordinate getCurrentCoordinate() throws UnsupportedOperationException {
        throw new UnsupportedOperationException("This method is currently unsupported.");
    }


    /**
     * Return the String name of the zip code passed in.
     *
     * @param _zipCode
     * @return Location Name
     * @throws IOException
     * @throws JSONException
     */
    public String getNameOfLocation(int _zipCode) throws IOException, JSONException {
        JSONObject locationJSON = this.getResponse(_zipCode)
                .getJSONArray("results")
                .getJSONObject(0);

        String formattedLocation = locationJSON.getString("formatted_address");
        return formattedLocation;
    }


    /**
     * Return LocationCoordinate of the zip code passed in.
     *
     * @param _zipCode
     * @return
     * @throws IOException
     * @throws JSONException
     */
    public LocationCoordinate zipCodeToCoordinate(int _zipCode) throws IOException, JSONException {
        JSONObject locationJSON = this.getResponse(_zipCode)
                .getJSONArray("results")
                .getJSONObject(0)
                .getJSONObject("location");

        double latitude = locationJSON.getDouble("lat"),
                longitude = locationJSON.getDouble("lng");
        return new LocationCoordinate(latitude, longitude);
    }
}