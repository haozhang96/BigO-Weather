package edu.uncg.csc.bigo.weather.data;

import java.util.ArrayList;

/**
 * This interface will describe all the methods which must be implemented for the text file database.
 * @author Harman Bains
 * @updated 10/29/2018
 */

public interface DataInterface {

 //   public abstract void create();

    public abstract void insert(int _zipCode, String _latitude, String _longitude);

    public abstract void remove(String _zipCode);

    public abstract void read(String _zipCode);

    // Check if the zip code is saved in the text file.
    public abstract boolean checkFile(int _zipCode);

}
