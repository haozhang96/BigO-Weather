package edu.uncg.csc.bigo.weather.data;

/**
 * This class handles the CRUD operations for the text file. It implements the methods located in
 * DataInterface.
 *
 * @author
 * @updated
 */

import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import static edu.uncg.csc.bigo.weather.data.CreateFile.newFile;

public class DataStore implements DataInterface {

    /**
     * Inserts a location into the text file after checking if the location already exists by calling
     * checkFile. If it does not exist, then insert it.
     * exists, then it does not insert.
     * @param _zipCode
     * @param _latitude
     * @param _longitude
     * @return
     */
    @Override
    public void insert(int _zipCode, String _latitude, String _longitude) {

        FileWriter locationWriter;

        if (!checkFile(_zipCode)) {

            try {
                // Create a file writer for the text file and allowing for appending.
                locationWriter = new FileWriter(newFile, true);
                locationWriter.append(String.valueOf(_zipCode) + " " + _latitude + " " + _longitude + "\n");
                // Flush will clear the file writer to avoid unintended writing to text file.
                locationWriter.flush();

            } catch (IOException e) {
                Log.e("Exception", " insert error in DataStore " + e.toString());
            }
        } else {
            Log.e("Error ", + _zipCode + " is already saved.");
        }
    }

    /**
     * Checks the text file for a location by searching for the given zip code and returns true
     * if found.
     * @param _zipCode
     */
    @Override
    public boolean checkFile(int _zipCode) {

        // Pass in the directory and file name to be read.
        File loadFile = new File(CreateFile.txtDir, "test.txt");

        // An arraylist to hold the zip codes and coordinates for simple searching.
        ArrayList<String> locationArray = new ArrayList<String>();

        try (Scanner scanner = new Scanner(loadFile)) {

            while (scanner.hasNext()) {

                // Add each one to the arraylist.
                locationArray.add(scanner.next());

            }
        } catch (FileNotFoundException | InputMismatchException e) {
            e.printStackTrace();
        }

        return locationArray.contains(String.valueOf(_zipCode));
    }

    /**
     * Removes a saved location from the text file.
     * @param _zipCode
     */
    @Override
    public void remove(String _zipCode) {

    }

    /**
     * Read the zip codes in the text file and if selected, return the coordinated for easier weather
     * information retrieval.
     * @param _zip
     */
    @Override
    public void read(String _zip) {

        // Pass in the directory and file name to be read.
        File loadFile = new File(CreateFile.txtDir, "test.txt");

        List<Integer> cee = new ArrayList<>();


        try (Scanner scanner = new Scanner(loadFile)) {
            //      int x = Integer.parseInt(scanner.next());

            //     int re = Integer.parseInt(scanner.next());
            //       int re = scanner.nextInt();
            //     Log.e("RE", " is " + re);

            while (scanner.hasNextLine()) {
                //     Log.e("Here ", " is everything " + scanner.nextInt());

                cee.add(scanner.nextInt());


            }
            Log.d("list ", cee.toString());
/*
            while (scanner.hasNextLine()){
                Log.e("HERE", " IN WHILE LOOP");

                String line = scanner.next();
                Log.e("STRING  ", " is " + line);



                String newww = line.substring(0,6);

                int z = Integer.parseInt(newww);

                Log.e(" newww STRING  ", " is " + newww);

                Log.e(" Z ", " is " + z);

//                if(z==_zip){
  //                  Log.e("MATCH ", " Z == _ZIP");
    //            } else{
      //              Log.e("no match ", " z is " + z + " zip is " + _zip );
        //        }
            }
*/


            //    while (scanner.hasNextLine()) {
            //            Log.e(" scanner next ", " is: " + scanner.next());
            //           Log.e(" RE ", " is " + re);

            // re = scanner.nextInt();
            //      Log.e("new RE", " the new RE is: " + re);


            //      if(re == _zip){
            //        Log.e(" MATCH", " next int matches zipcode " + re + " == " + _zip);
            //       }else  {
            //       Log.e(" NO match found", " something in txt file " + re + " zip == " +_zip);
            // Loop through each zip code in the file.
            //      re=scanner.nextInt();
            //    Log.e("new RE", " the new RE is: " + re);


            //   }

//re = scanner.nextInt();

            //   scanner.close();

        } catch (FileNotFoundException | NumberFormatException |
                InputMismatchException e)

        {
            e.printStackTrace();
        }


    }


}
