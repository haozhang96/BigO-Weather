package edu.uncg.csc.bigo.weather.models.weather;

import org.json.JSONException;

import java.io.IOException;

import edu.uncg.csc.bigo.weather.models.api.WeatherAPI;
import edu.uncg.csc.bigo.weather.models.api.location.GeocodioAPI;
import edu.uncg.csc.bigo.weather.models.api.weather.DarkSkyAPI;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import edu.uncg.csc.bigo.weather.views.activities.MainActivity;

public class WeatherDataStringFormatter {

    static public String[]  formatCurrentWeather(int _zip) throws Exception {
        String[] weatherStringArray = new String[20];
        WeatherAPI darkSky = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoCurrent = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoCurrent.zipCodeToCoordinate(_zip);
        WeatherData weatherCurrent = darkSky.getCurrentWeather(location);

        weatherStringArray[0] = geoCurrent.getNameOfLocation(_zip);
        weatherStringArray[1] = weatherCurrent.getApparentTemperature().toString();
        weatherStringArray[2] = weatherCurrent.getCloudCover().toString();
        weatherStringArray[3] = weatherCurrent.getDewPoint().toString();
        weatherStringArray[4] = weatherCurrent.getHumidity().toString();
        weatherStringArray[5] = weatherCurrent.getLocation().toString();
        weatherStringArray[6] = weatherCurrent.getSummary();
        weatherStringArray[7] = weatherCurrent.getMoonPhase().toString();
        weatherStringArray[8] = weatherCurrent.getNearestStormDistance().toString();
        weatherStringArray[9] = weatherCurrent.getOzone().toString();
        weatherStringArray[10] = weatherCurrent.getPrecipitationIntensity().toString();
        weatherStringArray[11] = weatherCurrent.getPrecipitationProbability().toString();
        weatherStringArray[12] = weatherCurrent.getPressure().toString();
        weatherStringArray[13] = weatherCurrent.getTemperature().toString();
        weatherStringArray[14] = weatherCurrent.getTime().toString();
        weatherStringArray[15] = weatherCurrent.getUVIndex().toString();
        weatherStringArray[16] = weatherCurrent.getVisibility().toString();
        weatherStringArray[17] = weatherCurrent.getWindGust().toString();
        weatherStringArray[18] = weatherCurrent.getWindSpeed().toString();



        return weatherStringArray;
    }
}
