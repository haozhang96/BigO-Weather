package edu.uncg.csc.bigo.weather.controllers;

import org.json.JSONException;

import java.io.IOException;

import edu.uncg.csc.bigo.weather.models.api.WeatherAPI;
import edu.uncg.csc.bigo.weather.models.api.location.GeocodioAPI;
import edu.uncg.csc.bigo.weather.models.api.weather.DarkSkyAPI;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import edu.uncg.csc.bigo.weather.models.weather.WeatherData;
import edu.uncg.csc.bigo.weather.models.weather.WeatherDataStringFormatter;
import edu.uncg.csc.bigo.weather.views.activities.MainActivity;
import edu.uncg.csc.bigo.weather.models.util.ReadTxt;

/**
 * This is the placeholder class for the weather controller
 */
public final class WeatherController {

    /**
     * The getWeatherCurrent method returns the current weather data from the weather models. It requires
     * a zipcode from the user, and uses a switch statement to determine the location.
     * 0 - Returns the name of the location.
     * 1 - Returns the weather summary at the location.
     * 2 - Returns the temerature at the location.
     * 3 - Returns the probability of precipitation.
     * 4 - Returns the dew point.
     * 5 - Returns the longitude and latitude of the location.
     *
     * @param _zip The zipcode integer.
     * @param _i the integer for which piece of weather you want.
     * @return returnString the string version of whatever data you requested.
     * @throws Exception
     */
    public static String[] getWeatherCurrent(int _zip) throws Exception {
        String[] test = WeatherDataStringFormatter.formatCurrentWeather(_zip);
        return test;
}

}