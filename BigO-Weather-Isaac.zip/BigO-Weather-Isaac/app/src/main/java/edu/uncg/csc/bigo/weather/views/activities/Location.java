package edu.uncg.csc.bigo.weather.views.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import edu.uncg.csc.bigo.weather.R;

public class Location extends AppCompatActivity {

    private TextView mTextMessage;
    private TextView TextViewZipFormat;
    protected EditText editTextZip;
    private Button button;
    private ImageView image;
    public int zipCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        //Initialize the EditText box.
        editTextZip = (EditText) findViewById(R.id.editTextZip);

        //Initialize the button
        button = (Button) findViewById(R.id.button);

        //Initialize the message TextView box
        //mTextMessage = (TextView) findViewById(R.id.currentMessage);

        //Initialize the formatting message TextView box
        TextViewZipFormat = (TextView) findViewById(R.id.TextViewZipFormat);

        //Initialize the image box
        //image = (ImageView) findViewById(R.id.imageView);

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Make sure the user inputs a properly formatted zip.
                if (editTextZip.getText().toString().length() < 5 || editTextZip.getText().toString().isEmpty()) {
                    TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                    //mTextMessage.setText(" ");
                    editTextZip.setText("");
                } else if (editTextZip.getText().toString().length() > 5) {
                    TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                    //mTextMessage.setText(" ");
                    editTextZip.setText("");
                }
                //If the zip is correctly formatted assign it to zipCode
                else if (editTextZip.getText().toString().length() == 5) {
                    zipCode = Integer.valueOf(editTextZip.getText().toString());
                    TextViewZipFormat.setText("");
                    startActivity(new Intent(Location.this, MainActivity.class));
                }
            }
        });
    }
}


