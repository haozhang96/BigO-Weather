package edu.uncg.csc.bigo.weather.models.weather;
/**
 * The WeatherDataStringForma
 */

import org.json.JSONException;

import java.io.IOException;

import edu.uncg.csc.bigo.weather.models.api.WeatherAPI;
import edu.uncg.csc.bigo.weather.models.api.location.GeocodioAPI;
import edu.uncg.csc.bigo.weather.models.api.weather.DarkSkyAPI;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import edu.uncg.csc.bigo.weather.views.activities.MainActivity;

public class WeatherDataStringFormatter {

    static public String[] formatCurrentWeather(int _zip) throws Exception {
        String[] currentStringArray = new String[20];
        WeatherAPI darkSkyCurrent = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoCurrent = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoCurrent.zipCodeToCoordinate(_zip);
        WeatherData weatherCurrent = darkSkyCurrent.getCurrentWeather(location);

        currentStringArray[0] = geoCurrent.getNameOfLocation(_zip);
        currentStringArray[1] = weatherCurrent.getApparentTemperature().toString();
        currentStringArray[2] = weatherCurrent.getCloudCover().toString();
        currentStringArray[3] = weatherCurrent.getDewPoint().toString();
        currentStringArray[4] = weatherCurrent.getHumidity().toString();
        currentStringArray[5] = weatherCurrent.getLocation().toString();
        currentStringArray[6] = weatherCurrent.getMoonPhase().toString();
        currentStringArray[7] = weatherCurrent.getNearestStormDistance().toString();
        currentStringArray[8] = weatherCurrent.getOzone().toString();
        currentStringArray[9] = weatherCurrent.getPrecipitationIntensity().toString();
        currentStringArray[10] = weatherCurrent.getPrecipitationProbability().toString();
        currentStringArray[11] = weatherCurrent.getPressure().toString();
        currentStringArray[12] = weatherCurrent.getSummary();
        currentStringArray[13] = weatherCurrent.getTemperature().toString();
        currentStringArray[14] = weatherCurrent.getTime().toString();
        currentStringArray[15] = weatherCurrent.getUVIndex().toString();
        currentStringArray[16] = weatherCurrent.getVisibility().toString();
        currentStringArray[17] = weatherCurrent.getWindGust().toString();
        currentStringArray[18] = weatherCurrent.getWindSpeed().toString();

        return currentStringArray;
    }

    static public String[] formatDailyWeather(int _zip) throws Exception {
        String[] dailyStringArray = new String[20];
        WeatherAPI darkSkyDaily = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoDaily = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoDaily.zipCodeToCoordinate(_zip);
        WeatherData weatherDaily = darkSkyDaily.getDailyWeather(location);


        dailyStringArray[0] = geoDaily.getNameOfLocation(_zip);
        dailyStringArray[1] = weatherDaily.getCloudCover().toString();
        dailyStringArray[2] = weatherDaily.getDewPoint().toString();
        dailyStringArray[3] = weatherDaily.getHumidity().toString();
        dailyStringArray[4] = weatherDaily.getLocation().toString();
        dailyStringArray[5] = weatherDaily.getMoonPhase().toString();
        dailyStringArray[6] = weatherDaily.getOzone().toString();
        dailyStringArray[7] = weatherDaily.getPrecipitationIntensity().toString();
        dailyStringArray[8] = weatherDaily.getPrecipitationProbability().toString();
        dailyStringArray[9] = weatherDaily.getPressure().toString();
        dailyStringArray[10] = weatherDaily.getSummary();
        dailyStringArray[11] = weatherDaily.getTime().toString();
        dailyStringArray[12] = weatherDaily.getUVIndex().toString();
        dailyStringArray[13] = weatherDaily.getVisibility().toString();
        dailyStringArray[14] = weatherDaily.getWindGust().toString();
        dailyStringArray[15] = weatherDaily.getWindSpeed().toString();

        return dailyStringArray;
    }

    static public String[] formatHourlyWeather(int _zip) throws Exception {
        String[] hourlyStringArray = new String[20];
        WeatherAPI darkSkyHourly = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoHourly = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoHourly.zipCodeToCoordinate(_zip);
        WeatherData weatherHourly = darkSkyHourly.getHourlyWeather(location);


        hourlyStringArray[0] = geoHourly.getNameOfLocation(_zip);
        hourlyStringArray[1] = weatherHourly.getApparentTemperature().toString();
        hourlyStringArray[2] = weatherHourly.getDewPoint().toString();
        hourlyStringArray[3] = weatherHourly.getHumidity().toString();
        hourlyStringArray[4] = weatherHourly.getLocation().toString();
        hourlyStringArray[5] = weatherHourly.getOzone().toString();
        hourlyStringArray[6] = weatherHourly.getPrecipitationIntensity().toString();
        hourlyStringArray[7] = weatherHourly.getPrecipitationProbability().toString();
        hourlyStringArray[8] = weatherHourly.getPressure().toString();
        hourlyStringArray[9] = weatherHourly.getSummary();
        hourlyStringArray[10] = weatherHourly.getTemperature().toString();
        hourlyStringArray[11] = weatherHourly.getTime().toString();
        hourlyStringArray[12] = weatherHourly.getUVIndex().toString();
        hourlyStringArray[13] = weatherHourly.getVisibility().toString();
        hourlyStringArray[14] = weatherHourly.getWindGust().toString();
        hourlyStringArray[15] = weatherHourly.getWindSpeed().toString();

        return hourlyStringArray;
    }
    static public String[] formatMinutelyWeather(int _zip) throws Exception {
        String[] minutelyStringArray = new String[5];
        WeatherAPI darkSkyMinutely = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoMinutely = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoMinutely.zipCodeToCoordinate(_zip);
        WeatherData weatherMinutely = darkSkyMinutely.getHourlyWeather(location);

        minutelyStringArray[0] = weatherMinutely.getPrecipitationIntensity().toString();
        minutelyStringArray[1] = weatherMinutely.getPrecipitationProbability().toString();
        minutelyStringArray[2] = weatherMinutely.getSummary();
        minutelyStringArray[3] = weatherMinutely.getTime().toString();

        return minutelyStringArray;
    }
}
