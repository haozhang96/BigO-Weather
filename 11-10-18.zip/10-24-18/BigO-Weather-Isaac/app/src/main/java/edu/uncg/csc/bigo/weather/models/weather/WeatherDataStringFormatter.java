package edu.uncg.csc.bigo.weather.models.weather;
/**
 * The WeatherDataStringFormatter class takes the weather data from DarkSkyAPI and GeocodioAPI and places
 * the individual pieces of Current, Hourly, Daily, and Minutely weather data into String arrays. The WeatherController
 * class can take these String arrays and give them to view files to display weather data to the user.
 *
 * @updated 10/24/18
 * @author John Isaac Wilkinson
 */

import org.json.JSONException;

import java.io.IOException;

import edu.uncg.csc.bigo.weather.models.api.WeatherAPI;
import edu.uncg.csc.bigo.weather.models.api.location.GeocodioAPI;
import edu.uncg.csc.bigo.weather.models.api.weather.DarkSkyAPI;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import edu.uncg.csc.bigo.weather.views.activities.MainActivity;

public class WeatherDataStringFormatter {
    /**
     * The formatCurrentWeather method creates the necessary objects to gather the current weather data
     * for the zipcode provided, and places the individual pieces of data into a String array to be
     * passed around by the Weather Controller. The indexes are organized as follows:
     *
     * 0 - The city, state, and zipcode
     * 1 - The temperature it appears to be
     * 2 - The cloud coverage
     * 3 - The dewpoint
     * 4 - The humidity
     * 5 - The location
     * 6 - The moon phase
     * 7 - The distance to the nearest storm
     * 8 - The level of Ozone
     * 9 - The intensity of precipitaion
     * 10 - The probability of precipitaion
     * 11 - The pressure
     * 12 - The summary of the weather
     * 13 - The actual temperature
     * 14 - The time of the query
     * 15 - The UV index
     * 16 - The distance of visibility
     * 17 - The speed of the wind gust
     * 18 - The speed of the wind
     *
     * @param _zip The Zipcode of the location to check the weather of.
     * @return currentStringArray The array of Strings containing the current weather information.
     * @throws Exception
     */
    static public String[] formatCurrentWeather(int _zip) throws Exception {
        String[] currentStringArray = new String[20];
        WeatherAPI darkSkyCurrent = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoCurrent = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoCurrent.zipCodeToCoordinate(_zip);
        WeatherData weatherCurrent = darkSkyCurrent.getCurrentWeather(location);

        currentStringArray[0] = geoCurrent.getNameOfLocation(_zip);
        currentStringArray[1] = weatherCurrent.getApparentTemperature().toString();
        currentStringArray[2] = weatherCurrent.getCloudCover().toString();
        currentStringArray[3] = weatherCurrent.getDewPoint().toString();
        currentStringArray[4] = weatherCurrent.getHumidity().toString();
        currentStringArray[5] = weatherCurrent.getLocation().toString();
        currentStringArray[6] = weatherCurrent.getMoonPhase().toString();
        currentStringArray[7] = weatherCurrent.getNearestStormDistance().toString();
        currentStringArray[8] = weatherCurrent.getOzone().toString();
        currentStringArray[9] = weatherCurrent.getPrecipitationIntensity().toString();
        currentStringArray[10] = weatherCurrent.getPrecipitationProbability().toString();
        currentStringArray[11] = weatherCurrent.getPressure().toString();
        currentStringArray[12] = weatherCurrent.getSummary();
        currentStringArray[13] = weatherCurrent.getTemperature().toString();
        currentStringArray[14] = weatherCurrent.getTime().toString();
        currentStringArray[15] = weatherCurrent.getUVIndex().toString();
        currentStringArray[16] = weatherCurrent.getVisibility().toString();
        currentStringArray[17] = weatherCurrent.getWindGust().toString();
        currentStringArray[18] = weatherCurrent.getWindSpeed().toString();

        return currentStringArray;
    }

    /**
     * The formatDailyWeather method creates the necessary objects to gather the daily weather data
     * for the zipcode provided, and places the individual pieces of data into a String array to be
     * passed around by the Weather Controller. The indexes are organized as follows:
     *
     * 0 - The city, state, and zipcode
     * 1 - The cloud coverage
     * 2 - The dewpoint
     * 3 - The humidity
     * 4 - The location
     * 5 - The moon phase
     * 6 - The level of Ozone
     * 7 - The intensity of precipitaion
     * 8 - The probability of precipitaion
     * 9 - The pressure
     * 10 - The summary of the weather
     * 11 - the temperature
     * 12 - The time of the query
     * 13 - The UV index
     * 14 - The distance of visibility
     * 15 - The speed of the wind gust
     * 16 - The speed of the wind
     *
     * @param _zip The Zipcode of the location to check the weather of.
     * @return currentStringArray The array of Strings containing the daily weather information.
     * @throws Exception
     */
    static public String[] formatDailyWeather(int _zip) throws Exception {
        String[] dailyStringArray = new String[20];
        WeatherAPI darkSkyDaily = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoDaily = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoDaily.zipCodeToCoordinate(_zip);
        WeatherData weatherDaily = darkSkyDaily.getDailyWeather(location);


        dailyStringArray[0] = geoDaily.getNameOfLocation(_zip);
        dailyStringArray[1] = weatherDaily.getCloudCover().toString();
        dailyStringArray[2] = weatherDaily.getDewPoint().toString();
        dailyStringArray[3] = weatherDaily.getHumidity().toString();
        dailyStringArray[4] = weatherDaily.getLocation().toString();
        dailyStringArray[5] = weatherDaily.getMoonPhase().toString();
        dailyStringArray[6] = weatherDaily.getOzone().toString();
        dailyStringArray[7] = weatherDaily.getPrecipitationIntensity().toString();
        dailyStringArray[8] = weatherDaily.getPrecipitationProbability().toString();
        dailyStringArray[9] = weatherDaily.getPressure().toString();
        dailyStringArray[10] = weatherDaily.getSummary();
        //Displays NaN
        dailyStringArray[11] = weatherDaily.getTemperature().toString();
        dailyStringArray[12] = weatherDaily.getTime().toString();
        dailyStringArray[13] = weatherDaily.getUVIndex().toString();
        dailyStringArray[14] = weatherDaily.getVisibility().toString();
        dailyStringArray[15] = weatherDaily.getWindGust().toString();
        dailyStringArray[16] = weatherDaily.getWindSpeed().toString();

        return dailyStringArray;
    }

    /**
     * The formatHourlyWeather method creates the necessary objects to gather the hourly weather data
     * for the zipcode provided, and places the individual pieces of data into a String array to be
     * passed around by the Weather Controller. The indexes are organized as follows:
     *
     * 0 - The city, state, and zipcode
     * 1 - The temperature it appears to be
     * 3 - The dewpoint
     * 4 - The humidity
     * 5 - The location
     * 8 - The level of Ozone
     * 9 - The intensity of precipitaion
     * 10 - The probability of precipitaion
     * 11 - The pressure
     * 12 - The summary of the weather
     * 13 - The actual temperature
     * 14 - The time of the query
     * 15 - The UV index
     * 16 - The distance of visibility
     * 17 - The speed of the wind gust
     * 18 - The speed of the wind
     *
     * @param _zip The Zipcode of the location to check the weather of.
     * @return currentStringArray The array of Strings containing the hourly weather information.
     * @throws Exception
     */
    static public String[] formatHourlyWeather(int _zip) throws Exception {
        String[] hourlyStringArray = new String[20];
        WeatherAPI darkSkyHourly = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoHourly = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoHourly.zipCodeToCoordinate(_zip);
        WeatherData weatherHourly = darkSkyHourly.getHourlyWeather(location);


        hourlyStringArray[0] = geoHourly.getNameOfLocation(_zip);
        hourlyStringArray[1] = weatherHourly.getApparentTemperature().toString();
        hourlyStringArray[2] = weatherHourly.getDewPoint().toString();
        hourlyStringArray[3] = weatherHourly.getHumidity().toString();
        hourlyStringArray[4] = weatherHourly.getLocation().toString();
        hourlyStringArray[5] = weatherHourly.getOzone().toString();
        hourlyStringArray[6] = weatherHourly.getPrecipitationIntensity().toString();
        hourlyStringArray[7] = weatherHourly.getPrecipitationProbability().toString();
        hourlyStringArray[8] = weatherHourly.getPressure().toString();
        hourlyStringArray[9] = weatherHourly.getSummary();
        hourlyStringArray[10] = weatherHourly.getTemperature().toString();
        hourlyStringArray[11] = weatherHourly.getTime().toString();
        hourlyStringArray[12] = weatherHourly.getUVIndex().toString();
        hourlyStringArray[13] = weatherHourly.getVisibility().toString();
        hourlyStringArray[14] = weatherHourly.getWindGust().toString();
        hourlyStringArray[15] = weatherHourly.getWindSpeed().toString();

        return hourlyStringArray;
    }

    /**
     * The formatMinutelyWeather method creates the necessary objects to gather the minutely weather data
     * for the zipcode provided, and places the individual pieces of data into a String array to be
     * passed around by the Weather Controller. The indexes are organized as follows:
     *
     * 0 - The city, state, and zipcode
     * 1 - The intensity of precipitation
     * 2 - The probability of precipitation
     * 3 - The summary of the weather
     * 4 - The time of the query
     *
     * @param _zip The Zipcode of the location to check the weather of.
     * @return currentStringArray Rhe array of Strings containing the current weather information.
     * @throws Exception
     */
    static public String[] formatMinutelyWeather(int _zip) throws Exception {
        String[] minutelyStringArray = new String[5];
        WeatherAPI darkSkyMinutely = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoMinutely = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoMinutely.zipCodeToCoordinate(_zip);
        WeatherData weatherMinutely = darkSkyMinutely.getHourlyWeather(location);

        minutelyStringArray[0] = geoMinutely.getNameOfLocation(_zip);
        minutelyStringArray[1] = weatherMinutely.getPrecipitationIntensity().toString();
        minutelyStringArray[2] = weatherMinutely.getPrecipitationProbability().toString();
        minutelyStringArray[3] = weatherMinutely.getSummary();
        minutelyStringArray[4] = weatherMinutely.getTime().toString();

        return minutelyStringArray;
    }

    //FLUSH THIS OUT
    static public String[] formatDailyWeatherForecast(int _zip) throws Exception {
        String[] dailyForecastStringArray = new String[20];
        WeatherAPI  darkSkyDailyForecast = new DarkSkyAPI(MainActivity.Test.APIKEY_DARKSKY);
        GeocodioAPI geoDaily = new GeocodioAPI(MainActivity.Test.APIKEY_GEOCODIO);
        LocationCoordinate location = geoDaily.zipCodeToCoordinate(_zip);
        WeatherData weatherDailyForecast = ((DarkSkyAPI) darkSkyDailyForecast).getDailyWeatherForecast(location, 1);

        dailyForecastStringArray[0] = geoDaily.getNameOfLocation(_zip);
        dailyForecastStringArray[1] = weatherDailyForecast.getCloudCover().toString();
        dailyForecastStringArray[2] = weatherDailyForecast.getDewPoint().toString();
        dailyForecastStringArray[3] = weatherDailyForecast.getHumidity().toString();
        dailyForecastStringArray[4] = weatherDailyForecast.getLocation().toString();
        dailyForecastStringArray[5] = weatherDailyForecast.getMoonPhase().toString();
        dailyForecastStringArray[6] = weatherDailyForecast.getOzone().toString();
        dailyForecastStringArray[7] = weatherDailyForecast.getPrecipitationIntensity().toString();
        dailyForecastStringArray[8] = weatherDailyForecast.getPrecipitationProbability().toString();
        dailyForecastStringArray[9] = weatherDailyForecast.getPressure().toString();
        dailyForecastStringArray[10] = weatherDailyForecast.getSummary();
        dailyForecastStringArray[11] = weatherDailyForecast.getTime().toString();
        //displays NaN
        dailyForecastStringArray[12] = weatherDailyForecast.getTemperature().toString();
        dailyForecastStringArray[13] = weatherDailyForecast.getUVIndex().toString();
        dailyForecastStringArray[14] = weatherDailyForecast.getVisibility().toString();
        dailyForecastStringArray[15] = weatherDailyForecast.getWindGust().toString();
        dailyForecastStringArray[16] = weatherDailyForecast.getWindSpeed().toString();


        return dailyForecastStringArray;
    }
}
