package edu.uncg.csc.bigo.weather.views.activities;
/**
 *The MainActivity class controls buttons, textboxes, and the general activity of the program. We are
 *using it mainly to set up the UI necessary for testing.
 *
 * updated 10/24/18
 * @authors Hao Zhang, John Wilkinson, Steven Tran, Harman Bains.
 **/
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import edu.uncg.csc.bigo.weather.models.api.LocationAPI;
import edu.uncg.csc.bigo.weather.models.api.WeatherAPI;
import edu.uncg.csc.bigo.weather.models.api.weather.DarkSkyAPI;
import edu.uncg.csc.bigo.weather.models.api.location.GeocodioAPI;
import edu.uncg.csc.bigo.weather.models.metrics.units.TemperatureUnit;
import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;
import edu.uncg.csc.bigo.weather.models.weather.WeatherData;
import edu.uncg.csc.bigo.weather.R;
import edu.uncg.csc.bigo.weather.controllers.WeatherController;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private TextView TextViewZipFormat;
    private EditText editTextZip;
    private Button button;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            new Test().execute();
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    //The first three lines of this are by default in the MainActivity class.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize the EditText box.
        editTextZip = (EditText) findViewById(R.id.editTextZip);
        //Initialize the button.
        button = (Button) findViewById(R.id.button);
        //Initialize the message TextView box.
        mTextMessage = (TextView) findViewById(R.id.message);
        //Initialize the formatting message TextView box.
        TextViewZipFormat = (TextView) findViewById(R.id.TextViewZipFormat);
        //Set the button to listen for clicks, and do something when it hears one.
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Make sure the user inputs a properly formatted zip.
                if (editTextZip.getText().toString().length()< 5 || editTextZip.getText().toString().isEmpty()) {
                    TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                    mTextMessage.setText(" ");
                    editTextZip.setText("");
                }else if(editTextZip.getText().toString().length() > 5){
                    TextViewZipFormat.setText("Enter a Properly Formatted Zip");
                    mTextMessage.setText(" ");
                    editTextZip.setText("");
                }
                //If the zip is correctly formatted assign it to zipCode
                else if(editTextZip.getText().toString().length()==5){
                    int zipCode = Integer.valueOf(editTextZip.getText().toString());
                    TextViewZipFormat.setText("");
                    new Test().execute();


                }
            }
        });

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }


    /**
     * This is where we will test things
     */
    public class Test extends AsyncTask<Void, Void, String> {

        public static final String APIKEY_GEOCODIO = "f0905446086d00db93d937b64d0e999b3b45d5d";
        public static final String APIKEY_DARKSKY = "1fffd54fe65a40d92a13eb5d7e3e1fee";


        protected String doInBackground(Void... nothing) {
            try  {
                // Store a message buffer to append strings to.
                StringBuffer message = new StringBuffer();
                //Get the zipcode entered by the user.
                int zipCode = Integer.valueOf(editTextZip.getText().toString());

                //Testing the WeatherController methods
                String[] testDailyWeatherForecastController = WeatherController.getWeatherDailyForecast(zipCode);
                for (int i = 0; i<17; i++) {
                    message.append(testDailyWeatherForecastController[i]+"\n");
                }
                message.append("\n");

                String[] testDailyWeatherController = WeatherController.getWeatherDaily(zipCode);
                for (int i = 0; i<=17; i++){
                    message.append(testDailyWeatherController[i]+"\n");
                }
                message.append("\n");

                String[] testHourlyWeatherController = WeatherController.getWeatherHourly(zipCode);
                for (int i = 0; i<=15; i++){
                    message.append(testHourlyWeatherController[i]+"\n");
                }
                message.append("\n");

                message.append("Minutely: \n");
                String[] testMinutelyWeatherController = WeatherController.getWeatherMinutely(zipCode);
                for (int i = 0; i<=4; i++){
                    message.append(testMinutelyWeatherController[i]+"\n");
                }
                message.append("\n");

                message.append("Currently: \n");
                String[] testCurrentWeatherController = WeatherController.getWeatherCurrent(zipCode);
                for (int i = 0; i<=18; i++){
                    message.append(testCurrentWeatherController[i]+"\n");
                }




                return message.toString();
            } catch (Exception exception) {
                return exception.toString();
            }
        }


        protected void onPostExecute(String result) {
            mTextMessage.setText(result);
        }
    }
}