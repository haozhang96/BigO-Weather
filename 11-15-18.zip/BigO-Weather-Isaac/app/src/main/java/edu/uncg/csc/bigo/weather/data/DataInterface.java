package edu.uncg.csc.bigo.weather.data;

import java.util.ArrayList;

import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;

/**
 * This interface will describe all the methods which must be implemented for the text file database.
 * @author Harman Bains
 * @updated 10/29/2018
 */

public interface DataInterface {
    //   public abstract void create();

    public abstract void sortFile();

    public abstract LocationCoordinate returnCoordinates (int _zipCode);

    public abstract void insert(int _zipCode, String _latitude, String _longitude);

    // Check if the zip code is saved in the text file.
    public abstract boolean checkFile(int _zipCode);

    //Currently not in use.
    public abstract void remove(String _zipCode);

}
