package edu.uncg.csc.bigo.weather.data;

/**
 * This class creates a file on the device using OutputStreamWriter. The file will be saved on the
 * application directory under the file name passed in.
 * @updated 10/24/2018
 * @author Harman Bains
 *
 */
import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class SaveLocation {

    OutputStreamWriter outputWriter;

    /**
     * @param _context is passed in for the app to create the file.
     * of the app at that moment.
     * @return void. Creates the file.
     * @throws Exception in case the file was not created.
     */
    public void createFile (Context _context){

        // The name of the file created. Will be stored in another file along with API keys.
        final String fileName = "LocationFile.txt";

        try{

            // Uses OutputStreamWriter to create the file with the file name and context passed in.
            outputWriter = new OutputStreamWriter(_context.openFileOutput
                    (fileName, Context.MODE_PRIVATE));


        // check if the file exists before creating
  /*        //  File checkFile = new File(_context.getApplicationContext().getFilesDir(), "fileName");
              File checkFile = _context.getFileStreamPath(fileName);
                if(!checkFile.exists()){
                    outputWriter = new OutputStreamWriter(_context.openFileOutput
                            (fileName, Context.MODE_PRIVATE));
                }
  */

        }catch (Exception e){
            Log.e("Exception", " File creatation failed " + e.toString());
        }
    }

    /**
     * Inserts zip code and coordinates into the created text file.
     * @param _zipCode
     * @param _latitude
     * @param _longitude
     * @param _context
     */
    public void insertLocation (String _zipCode, String _latitude, String _longitude, Context _context) {
        try{
            outputWriter.write(_zipCode + " " + _latitude + " " + _longitude + "\n");
            outputWriter.close();

        }catch (Exception e){
            Log.e("Exception", " File insertion failed " + e.toString());
        }
    }
}

