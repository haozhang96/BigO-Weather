package edu.uncg.csc.bigo.weather.data;

/**
 * This class will read the zip code, latitude and longitude from the text file created in
 * CreateFile. It will return this information.
 * @author Harman Bains
 * @updated 10/24/2018
 */

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import edu.uncg.csc.bigo.weather.models.util.LocationCoordinate;

public class ReadFile {

    // This will read the information from the created file and use it load weather information.
    // Returns a LocationCoordinate that can be used.
    public LocationCoordinate readFromFile (Context _context){        // pass in the file name as well
        File findFile = new File(_context.getFilesDir(), "LocationFile.txt");

        StringBuilder readText = new StringBuilder();

        try{
            BufferedReader buffReader = new BufferedReader(new FileReader(findFile));
            String line;

            while ((line = buffReader.readLine()) != null){

            }
        }catch (Exception e){
            Log.e("Exception", " Unable to read text file" + e.toString());
        }
        return null;
    }
}
