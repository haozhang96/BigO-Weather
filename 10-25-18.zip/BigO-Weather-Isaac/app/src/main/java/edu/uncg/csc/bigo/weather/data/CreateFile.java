package edu.uncg.csc.bigo.weather.data;

import android.content.Context;
import android.util.Log;
import java.io.OutputStreamWriter;

public class CreateFile {

    OutputStreamWriter outputWriter;

    /**
     * @param _context is passed in for the app to create the file.
     * of the app at that moment.
     * @return void. Creates the file.
     * @throws Exception in case the file was not created.
     */
    public void createFile (Context _context){

        // The name of the file created. Will be stored in another file along with API keys.
        final String fileName = "LocationFile.txt";

        try{

            // Uses OutputStreamWriter to create the file with the file name and context passed in.
            outputWriter = new OutputStreamWriter(_context.openFileOutput
                    (fileName, Context.MODE_PRIVATE));


            // check if the file exists before creating
  /*        //  File checkFile = new File(_context.getApplicationContext().getFilesDir(), "fileName");
              File checkFile = _context.getFileStreamPath(fileName);
                if(!checkFile.exists()){
                    outputWriter = new OutputStreamWriter(_context.openFileOutput
                            (fileName, Context.MODE_PRIVATE));
                }
  */

        }catch (Exception e){
            Log.e("Exception", " File creatation failed " + e.toString());
        }
    }


}

