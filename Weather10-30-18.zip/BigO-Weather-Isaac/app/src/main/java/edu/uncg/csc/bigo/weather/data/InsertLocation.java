package edu.uncg.csc.bigo.weather.data;

/**
 * This class is used to insert locations into the text file.
 * @author
 * @updated
 */

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class InsertLocation {

    static File newFile;

    /**
     * Method to insert into the location file.
     * @param _zipCode
     * @param _latitude
     * @param _longitude
     * @param _context
     * @return void
     * @throws Exception in case the insertion could not be completed.
     */
    static FileWriter locationWriter;
    public static void insert(String _zipCode, String _latitude, String _longitude, Context _context) {
        try {
            locationWriter = new FileWriter(newFile, true);
            locationWriter.append(_zipCode + " " + _latitude + " " + _longitude + "\n");
            locationWriter.flush();

        } catch (IOException e) {
            Log.e("Exception", " insert error in CreateFile " + e.toString());
        }
    }

}
