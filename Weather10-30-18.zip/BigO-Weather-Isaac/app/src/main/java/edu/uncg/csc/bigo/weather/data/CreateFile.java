package edu.uncg.csc.bigo.weather.data;

/**
 * This class creates the directory and file where locations will be saved. Zip code, latitude and
 * longitude will be saved to the file.
 * @author Harman Bains
 * @updated 10/29/2018
 */

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {

    // The name of the file and directory created. Will be stored in another file along with API keys.
    final static String fileName = "LocationFile.txt";
    final static String directoryName = "LocationDirectory";
    static File txtDir;
    static File newFile;

    /**
     * @param _context is passed in for the app to create the file and directory.
     * of the app at that moment.
     * @return void. Creates the file and directory.
     * @throws Exception in case the file or directory were not created.
     */
    public static void createFile (Context _context){

        try{

           // Create the directory for the locations file.
           txtDir = new File (_context.getFilesDir(), directoryName);
           if (txtDir.exists() == false){
               txtDir.mkdir();
           }

           // Create the file in the directory made above.
            try{
                newFile = new File(txtDir, fileName);
            }catch (Exception e){
                Log.e("Exception", " could not create file in directory " + e.toString());
            }

        }catch (Exception e){
            Log.e("Exception", " could not create directory " + e.toString());
        }
    }

    /**
     * Method to insert into the location file.
     * @param _zipCode
     * @param _latitude
     * @param _longitude
     * @param _context
     * @return void
     * @throws Exception in case the insertion could not be completed.
     */
    static FileWriter locationWriter;
    public static void insert(String _zipCode, String _latitude, String _longitude, Context _context) {
        try {
            // Create a file writer for the text file and allowing for appending.
            locationWriter = new FileWriter(newFile, true);
            locationWriter.append(_zipCode + " " + _latitude + " " + _longitude + "\n");
            // Flush will clear the file writer to avoid unintended writing to text file.
            locationWriter.flush();

        } catch (IOException e) {
            Log.e("Exception", " insert error in CreateFile " + e.toString());
        }
    }


}

