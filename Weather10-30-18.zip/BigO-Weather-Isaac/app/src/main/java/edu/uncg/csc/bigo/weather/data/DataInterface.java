package edu.uncg.csc.bigo.weather.data;

import android.content.Context;

/**
 * This interface will describe all the methods which must be implemented for the text file database.
 * @author Harman Bains
 * @updated 10/29/2018
 */
public interface DataInterface {

    public abstract void insert(String _zipCode, String _latitude, String _longitude, Context _context);

    // May not be needed
    public abstract void remove(String _zipCode);

}
